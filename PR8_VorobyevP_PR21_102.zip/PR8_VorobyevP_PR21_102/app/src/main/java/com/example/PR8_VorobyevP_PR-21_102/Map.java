package com.example.PR8_VorobyevP_PR-21_102;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Map extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map);
    }
}